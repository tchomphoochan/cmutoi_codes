// 108 - Hothead
// Solution by NtpRc12

#include <algorithm>
#include <cstdio>
#include <vector>

using namespace std;

#define MAXN 140260

struct Edge{
	int v, t;
};

vector<Edge> graph[MAXN];

long long dp[3][MAXN];
int N, X;

void dfs(int u, int p){
	long long val0 = 0;
	long long val1 = 1ll<<55;
	long long val2 = 1ll<<55;

	long long tmp1 = 1ll<<55;
	long long tmp2 = 1ll<<55;

	dp[2][0] = 1ll<<55;

	for(int i=0;i<graph[u].size();i++){
		int v = graph[u][i].v;
		if(v == p) continue;
		dfs(v, u);
		val0 += dp[2][v]+X;
	}
	int idx1 = 0;
	for(int i=0;i<graph[u].size();i++){
		int v = graph[u][i].v;
		int w = graph[u][i].t;
		if(v == p) continue;
		if(val1 > val0+dp[1][v]+w-dp[2][v]-X){
			idx1 = v;	
			val1 = val0+dp[1][v]+w-dp[2][v]-X;
		}
	}
	for(int i=0;i<graph[u].size();i++){
		int v = graph[u][i].v;
		int w = graph[u][i].t;
		if(v == p) continue;
		if(v == idx1) continue;
		val2 = min(val2, val1+dp[1][v]+w-dp[2][v]-X);
	}
	dp[0][u] = val0;
	dp[1][u] = min(val0, val1);
	dp[2][u] = min(dp[1][u], val2);
}

int main(){
	scanf("%d%d", &N, &X);
	int root = 1;
	bool check = 0;
	for(int i=0;i<N-1;i++){
		int a, b, t;
		scanf("%d%d%d", &a, &b, &t);
		graph[a].push_back({b, t});
		graph[b].push_back({a, t});
		if(graph[root].size() < graph[a].size()) root = a;
		if(graph[root].size() < graph[b].size()) root = b;
		if(X >= t) check = 1;
	}
	for(int i=1;i<=N;i++) for(int j=0;j<3;j++) dp[j][i] = -1;
	if(N == 1){
		printf("0\n");
	}
	else if(graph[root].size() == N-1 && check == 0){
		long long x1 = 1ll<<55, x2 = 1ll<<55;

		long long sum = 0;
		for(int i=0;i<graph[root].size();i++){
			int v = graph[root][i].v;
			int w = graph[root][i].t;
			if(x1 > w){
				x1 = w;
			}
			sum += X;
		}
		printf("%lld\n", sum-X+x1);
	}
	else{
		dfs(root, 0);
		printf("%lld\n", dp[2][root]);	
	}
}
