// 133 - Xmas Beam
// Solution by noneTP

#include <bits/stdc++.h>
using namespace std;
#define PB push_back
#define MP make_pair
#define FI first
#define SE second
typedef long long LL;
typedef pair<int, int> pii;
typedef pair<int, long long> pil;
typedef pair<long long, int> pli;
typedef pair<long long, long long> pll;
typedef pair<pii, int> piipi;
typedef pair<int, pii> pipii;
typedef pair<pii, pii> piipii;
const int mod = 1e9 + 7; // popular mod
const int hf = 999983; // hash function

pii xy[100005];
multiset<int> ydiff;

int main(){
	ios_base::sync_with_stdio(false), cin.tie(NULL);
	int t;
	cin >> t;
	while(t--){
		ydiff.clear();
		int n, h, x, y;
		cin >> n >> h;
		for(int i=0;i<n;i++) cin >> x >> y, xy[i] = pii(x, y);
		sort(xy, xy+n);
		int l = 0, ans = 1e9;
		for(int i=0;i<n;i++){
			ydiff.insert(xy[i].SE);
			while(*--ydiff.end() - *ydiff.begin() >= h) ans = min(ans, xy[i].FI-xy[l].FI), ydiff.erase(ydiff.find(xy[l].SE)), l++;
		}
		if(ans == 1e9) cout << "-1" << endl;
		else cout << ans << endl;
	}
}