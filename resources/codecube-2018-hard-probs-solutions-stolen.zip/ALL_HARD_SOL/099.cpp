// 99 - Choco Pipe
// Solution by comtalyst

/*
 *	Task: Choco Pipe
 *	Lang: C/C++11
 *	Author: comtalyst
 *	Site: CodeCube
 *	Last Update: 22/12/2017
 */

#include <bits/stdc++.h>
//#pragma GCC optimize ("O3")
using namespace std;

/* Note
----------------------------
Learned : 
Bugs found & solved :
- forgot to check tree in initial position
- forgot to update sp+tree (above) in pq
Optimizations :
----------------------------
0 = up
1 = right
2 = down
3 = left
*/	

#define x first
#define y second
#define umap unordered_map
#define pqueue priority_queue
#define mset multiset
#define mp make_pair
#define mt make_tuple
#define long long long
#define MOD 1000000007
#define MAX (int)2e9
#define MIN (int)-2e9
#define FILEIN_ freopen("__in.txt","r",stdin)
#define FILEOUT_ freopen("__out.txt","w",stdout)
#define FILEIN(text) freopen(text,"r",stdin)
#define FILEOUT(text) freopen(text,"w",stdout)

pair<int,int> dr[] = {{-1,0},{0,1},{1,0},{0,-1}};
char field[105][105];
int sp[105][105][5],n,m,a,b,c;
bool valid(int x,int y,int z,int d,int oz){
	if(x < 1 || y < 1 || x > n || y > m || z == oz-2 || z == oz+2){
		return false;
	}
	if(sp[x][y][z] == -1 || sp[x][y][z] > d + ((z == oz)? a:b) + ((field[x][y] == 'X')? c:0)){
		sp[x][y][z] = d + ((z == oz)? a:b) + ((field[x][y] == 'X')? c:0);
		return true;
	}
	return false;
}

main(){
	int t,i,j,d,x,y,z;
	pqueue<tuple<int,int,int,int>> pq;
	memset(sp,-1,sizeof sp);
	
	scanf("%d %d %d %d %d",&a,&b,&c,&m,&n);
	for(i = 1; i <= n; i++){
		scanf("%s",field[i]+1);
	}
	sp[n][1][1] = ((field[n][1] == 'X')? c:0);
	pq.emplace(-sp[n][1][1],n,1,1);
	while(!pq.empty()){
		tie(d,x,y,z) = pq.top();
		pq.pop();
		d = -d;
		if(d > sp[x][y][z]){
			continue;
		}
//		printf("%d %d %d = %d\n",x,y,z,d);
		for(i = 0; i < 4; i++){
			if(valid(x+dr[i].x, y+dr[i].y,i,d,z)){
				pq.emplace(-sp[x+dr[i].x][y+dr[i].y][i],x+dr[i].x,y+dr[i].y,i);
			}
		}
	} 
	printf("%d\n",min(sp[1][m][1] + a,sp[1][m][0] + b));

	return 0;	
}