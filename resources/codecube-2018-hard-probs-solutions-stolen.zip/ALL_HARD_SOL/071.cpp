// 71 - stella
// Solution by Arun_Wong

#include <stdio.h>
#include <set>
#include <queue>
typedef struct node node;
struct node
{
	int t, h, v, i;
};
bool operator<(node a, node b)
{
	return (a.t > b.t);
}
std::priority_queue<node> RadQ;
typedef struct stone stone;
struct stone
{
	int v, r, i;
};
bool operator<(stone a, stone b)
{
	return (a.v > b.v || (a.v == b.v && a.i < b.i) || (a.v == b.v && a.i == b.i && a.r < b.r));
}
std::multiset<stone> Stock;
int main()
{
	int K;
	scanf("%d", &K);
	int i;
	char c1, c2;
	int v, h;
	node p;
	long long ans = 0;
	for (i = 0; i < K; i++)
	{
		while (!RadQ.empty())
		{
			p = RadQ.top();
			if (p.t > i)
				break;
			//printf("RadQ pop %d %d %d %d\n", p.t, p.h, p.v, p.i);
			RadQ.pop();
			if (Stock.find({p.v, 1, p.i}) != Stock.end())
			{
				Stock.erase(Stock.find({p.v, 1, p.i}));
				if (p.v/2 != 0)
				{
					Stock.insert({p.v/2, 1, p.i});
					RadQ.push({p.t + p.h, p.h, p.v/2, p.i});
				}
			}
			//printf("RadQ push %d %d %d %d\n", p.t + p.h, p.h, p.v/2, p.i);
		}
		scanf(" %c", &c1);
		if (c1 == 'c')
		{
			scanf(" %c", &c2);
			scanf("%d", &v);
			if (c2 == 'n')
			{
				Stock.insert({v, 0, i});
				//printf("Stock %d %d %d\n", v, 0, i);
			}
			else
			{
				scanf("%d", &h);
				Stock.insert({v, 1, i});
				//printf("Stock %d %d %d\n", v, 1, i);
				RadQ.push({i + h, h, v, i});
				//printf("RadQ push %d %d %d %d\n", i + h, h, v, i);
			}
		}
		else
		{
			if (Stock.size() > 0)
			{
				ans += (long long) (Stock.begin())->v;
				//printf("ans %d\n", ans);
				Stock.erase(Stock.begin());
			}
		}
	}
	printf("%lld\n%d", ans, Stock.size());
}