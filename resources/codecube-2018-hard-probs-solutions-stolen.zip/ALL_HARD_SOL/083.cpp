// 83 - เก็บกู้ระเบิด Bomb Disposal
// Solution by coppercandle

#include <bits/stdc++.h>
using namespace std;
int dist[15][1<<15];
int a[15];
struct node
{
	int u, mask;
	node(){}
	node(int a, int c)
	{
		u = a;
		mask = c;
	}
};
int main()
{
	int tt;
	scanf("%d", &tt);
	while(tt--)
	{
		memset(dist, 0, sizeof dist);
		//dist.clear();
		int n, p;
		deque<node> deq;
		scanf("%d %d", &n, &p);
		for(int i = 0; i< n; i++)
		{
			scanf("%d", a+i);
			a[i]--;
		}
		for(int i = 0; i< n; i++)
		{
			dist[i][0] = 1;
			deq.push_back(node(i, 0));
		}
		//int best = 1e9;
		while(!deq.empty())
		{
			node x = deq.front();
			deq.pop_front();
			int u = x.u, mask = x.mask;
			int d = dist[u][mask];
			bool dis = 0;
			int til = -1;
			int bits = 0;
			for(int i = 0; i< n; i++)
			{
				if(!((1<<i) & mask))
				{
					//printf("ei%d %d\n", i, til);
					dis = 1;
					if(til == -1)
					{
						til = i;
					}
				}
				if(dis && ((1<<i) & mask)) bits++;
			}
			//printf("%d %d %d %d\n", u, til, mask, d);
			//system("pause");
			if(til == -1)
			{
				printf("%d\n", d-1);
				break;
			}
			if(a[u] == til)
			{
				if(dist[u][mask|(1<<til)] == 0 || d< dist[u][mask|(1<<til)])
				{
					dist[u][mask|(1<<til)] = d;
					deq.push_front(node(u, mask|(1<<til)));	
				}
			}
			else if(bits< p)
			{
				int temp = mask | (1<<a[u]);
				if(dist[u][temp] == 0 || d< dist[u][temp])
				{
					dist[u][temp] = d;
					deq.push_front(node(u, temp));
				}
			}
			if(u) 
			{
				if(dist[u-1][mask] == 0 || 1+d< dist[u-1][mask])
				{
					dist[u-1][mask] = 1+d;
					deq.push_back(node(u-1, mask));
				}
			}
			if(u+1< n)
			{
				if(dist[u+1][mask] == 0 || 1+d < dist[u+1][mask])
				{
					dist[u+1][mask] = 1+d;
					deq.push_back(node(u+1, mask));
				}
			}
		}
	}
}