// 187 - string
// Solution by win11905

#include <bits/stdc++.h>
using namespace std;

struct item {
	int key, prio, cnt;
	item *l, *r;
	bool rev;
	item(int key) : key(key), prio(rand()), cnt(1), l(NULL), r(NULL) { }
};

using pitem = item*;

int cnt(pitem t) { return t ? t->cnt : 0; }
void upd(pitem t) { if(t) t->cnt = cnt(t->l) + cnt(t->r) + 1; }

void push(pitem t) {
	if(t) if(t->rev) {
		t->rev = false;
		swap(t->l, t->r);
		if(t->l) t->l->rev ^= 1;
		if(t->r) t->r->rev ^= 1;
	}
}

void split(pitem t, int key, pitem &l, pitem &r) {
	push(t);
	if(!t) return void(l = r = NULL);
	if(key <= cnt(t->l)) split(t->l, key, l, t->l), r = t;
	else split(t->r, key - cnt(t->l) - 1, t->r, r), l = t;
	upd(t);
}

void merge(pitem &t, pitem l, pitem r) {
	push(l), push(r);
	if(!l || !r) t = l ? l : r;
	else if(l->prio > r->prio) merge(l->r, l->r, r), t = l;
	else merge(r->l, l, r->l), t = r;
	upd(t);
}

void print(pitem t) {
	if(!t) return;
	push(t);
	print(t->l);
	printf("%c", t->key);
	print(t->r);
}

pitem t;
char A[100005];
int m;

int main() {
	scanf("%s", A);
	for(int i = 0; A[i]; ++i) merge(t, t, new item(A[i]));
	scanf("%d", &m);
	while(m--) {
		char met; scanf(" %c", &met);
		if(met == 'R') {
			int a, b;
			scanf("%d %d", &a, &b);
			pitem t1, t2, t3;
			split(t, a-1, t1, t2);
			split(t2, b-a+1, t2, t3);
			t2->rev ^= 1;
			merge(t, t1, t2);
			merge(t, t, t3);
		} else {
			int x; scanf("%d", &x); 
			scanf("%s", A);
			pitem t1;
			split(t, x, t, t1);
			for(int i = 0; A[i]; ++i) merge(t, t, new item(A[i]));
			merge(t, t, t1);
		}
	}
	print(t);
}