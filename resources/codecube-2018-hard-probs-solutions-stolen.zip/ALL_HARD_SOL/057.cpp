// 57 - พลังผลต่างเจ็ท (Jet Diff Power)
// Solution by Practising

#include <iostream>
#include <vector>
#include <cmath>
#define MAX 2000000000
using namespace std;
int main() {
	ios::sync_with_stdio(false);
	int n, a;
	bool c = 0;
	cin >> n;
	vector<int> v(n + 1);
	vector< vector<int> >  d(2, vector<int>(101));
	for (int i = 1; i <= n; i++) {
		cin >> v[i];
	}
	cin >> a;
	for (int i = 1; i <= n; i++) {
		c = !c;
		int x, mn = MAX, iMn = v[i];
		for (int k = v[i - 1]; k <= 100; k++) {
			x = a*fabs(k - v[i]) + d[!c][k];
			if (x < mn) {
				mn = x;
				iMn = k;
			}
		}
		d[c][v[i]] = mn;
		for (int j = v[i] + 1; j <= 100; j++) {
			mn = MAX;
			int lf, rg;
			lf = iMn - 2 < v[i - 1] ? v[i - 1] : iMn - 2;
			rg = iMn + 2 > 100 ? 100 : iMn + 2;
			for (int k = lf; k <= rg; k++) {
				x = a*fabs(k - j) + (v[i] - j)*(v[i] - j) + d[!c][k];
				if (x < mn) {
					mn = x;
					iMn = k;
				}
			}
			d[c][j] = mn;
		}
	}
	int mn = MAX;
	for (int i = v[n]; i <= 100; i++) {
		mn = d[c][i] < mn ? d[c][i] : mn;
	}
	cout << mn << endl;
	return 0;
}