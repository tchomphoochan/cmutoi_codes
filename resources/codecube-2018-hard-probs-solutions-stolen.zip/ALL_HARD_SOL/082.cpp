// 82 - OR Operator
// Solution by noneTP

#include <bits/stdc++.h>
using namespace std;
#define PB push_back
#define MP make_pair
#define FI first
#define SE second
typedef long long LL;
typedef pair<int, int> PII;
typedef pair<int, long long> PIL;
typedef pair<long long, int> PLI;
typedef pair<long long, long long> PLL;
typedef pair<int, PII> PIPII;
const int MOD = 1e9+7; // popular mod
const int HF = 999983; // hash function
/* ------- end small pattern ------- */

int a[2005], dp[2005];

int main(){
	int n, k;
	scanf("%d%d", &n, &k);
	for(int i=1;i<=n;i++) scanf("%d", &a[i]);
	LL bits = 1LL<<50;
	bool setbegin = 0;
	LL ans = 0;
	while(bits){
		if(!setbegin){
			LL ret = 0;
			int ck = 1;
			for(int j=1;j<=n;j++){
				if(ret >= bits) {ck = 2e9; break;}
				if(ret+a[j] >= bits) ck++, ret=a[j];
				else ret+=a[j];
			}
			if(ck > k) ans+=bits, setbegin = 1;
		}
		else{
			dp[0] = 0;
			LL ret = ans+bits;
			for(int r=1;r<=n;r++){
				dp[r] = 2e9;
				LL sum = 0;
				for(int l=r;l>=1;l--){
					sum+=a[l];
					if(((ans|sum) < (ans|bits)) && ((sum&bits) == 0)) dp[r] = min(dp[r], dp[l-1] + 1);
				}
			}
			if(dp[n] > k) ans+=bits;
		}
		bits/=2;
	}
	printf("%lld\n", ans);
}