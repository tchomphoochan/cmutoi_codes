// 153 - Seven Gems
// Solution by spnautlius

//spnauT
#include <bits/stdc++.h>
#define FOR(i,a,b) for(int _=b,i=a;i<_;++i)
#define ROF(i,b,a) for(int _=a,i=b;i>_;--i)
#define REP(n) for(int _=(n);_--;)
#define _1 first
#define _2 second
#define PB push_back
#define SZ(x) int((x).size())
#define ALL(x) begin(x),end(x)
#define MSET(m,v) memset(m,v,sizeof(m))
#define MAX_PQ(T) priority_queue<T>
#define MIN_PQ(T) priority_queue<T,vector<T>,greater<T>>
#define IO {ios_base::sync_with_stdio(0);cin.tie(0);}
#define nl '\n'
#define cint1(a) int a;cin>>a
#define cint2(a,b) int a,b;cin>>a>>b
#define cint3(a,b,c) int a,b,c;cin>>a>>b>>c
using namespace std;using LL=int64_t;using PII=pair<int,int>;
using VI=vector<int>;using VL=vector<LL>;using VP=vector<PII>;
template<class A,class B>bool mina(A&x,B&&y){return y<x?(x=forward<B>(y),1):0;}
template<class A,class B>bool maxa(A&x,B&&y){return x<y?(x=forward<B>(y),1):0;}

const int MAX_N {204};
const int MAX_G {128};
const int MAX_T {6};
const int inf {100000000};
const int dr[5] = {0, 0, 1, 0, -1};
const int dc[5] = {0, 1, 0, -1, 0};

char S[MAX_N][MAX_N];

int dist[MAX_N][MAX_N][MAX_G][MAX_T];
int gem_id[MAX_N][MAX_N];
int PC[MAX_G];

int main()
{
	IO;
	cint2(R,C);
	FOR(i,0,R) cin >> S[i];

	FOR(i,0,MAX_G) PC[i] = __builtin_popcount(i);

	fill(dist[0][0][0], dist[R][0][0], inf);
	fill(gem_id[0], gem_id[R], -1);

	int g {0};
	int r0 {-1};
	int c0 {-1};
	FOR(i,0,R) FOR(j,0,C)
	{
		char c {S[i][j]};
		if(c == 'S')
		{
			r0 = i;
			c0 = j;
		}
		else if(c == 'G')
			gem_id[i][j] = g++;
	}

	using T4 = tuple<int,int,int,int>;
	queue<T4> Q;
	auto f = [&](int r, int c, int g, int t)
	{
		if(r >= 0 and r < R and c >= 0 and c < C)
		{
			char a {S[r][c]};
			if(a == 'G') g |= 1 << gem_id[r][c];

			int n = PC[g];
			int t1 {t % 6};
			if(a == '#') return;
			if(a >= '1' and a <= '6')
			{
				int ta {int(a - '0')};
				if(n < ta and t1 != ta % 6) return;
			}
			if(mina(dist[r][c][g][t1], t)) Q.push(T4(r,c,g,t));
		}
	};

	f(r0, c0, 0, 1);
	while(!Q.empty())
	{
		int r, c, g, t;
		tie(r, c, g, t) = Q.front();
		Q.pop();

		if(g == MAX_G - 1)
		{
			cout << t-1 << nl;
			return 0;
		}

		FOR(dir,0,5) f(r+dr[dir], c+dc[dir], g, t+1);
	}

	cout << -1 << nl;

	return 0;
}
