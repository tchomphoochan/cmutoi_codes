// 58 - Jet's Scouting
// Solution by spnautilus

//spnauT
#include <bits/stdc++.h>
#define FOR(i,a,b) for(int _=b,i=a;i<_;++i)
#define ROF(i,b,a) for(int _=a,i=b;i>_;--i)
#define REP(n) for(int _=(n);_--;)
#define _1 first
#define _2 second
#define PB push_back
#define SZ(x) int((x).size())
#define ALL(x) begin(x),end(x)
#define MSET(m,v) memset(m,v,sizeof(m))
#define MAX_PQ(T) priority_queue<T>
#define MIN_PQ(T) priority_queue<T,vector<T>,greater<T>>
#define IO {ios_base::sync_with_stdio(0);cin.tie(0);}
#define nl '\n'
#define cint1(a) int a;cin>>a
#define cint2(a,b) int a,b;cin>>a>>b
#define cint3(a,b,c) int a,b,c;cin>>a>>b>>c
using namespace std;using LL=int64_t;using PII=pair<int,int>;
using VI=vector<int>;using VL=vector<LL>;using VP=vector<PII>;
template<class A,class B>bool mina(A&x,B&&y){return y<x?(x=forward<B>(y),1):0;}
template<class A,class B>bool maxa(A&x,B&&y){return x<y?(x=forward<B>(y),1):0;}

const int MAX_R {304};
const int MAX_C {304};
const int MAX_N {200000};
const int inf {1000000000};

char B[MAX_R][MAX_C];
int id_h[MAX_R][MAX_C]; // '-'
int id_v[MAX_R][MAX_C]; // '|'
int id_s[MAX_R][MAX_C]; // '/'
int id_b[MAX_R][MAX_C]; // '\'

VI E[MAX_N];
int dist[MAX_N];

int main()
{
	IO;
	cint3(R,C,K);
	FOR(i,0,R) cin >> B[i];
	MSET(id_h,-1);
	MSET(id_v,-1);
	MSET(id_s,-1);
	MSET(id_b,-1);

	int id {0};
	int id_n {0};
	auto use1 = [&]()
	{
		++id_n;
		return id;
	};
	auto reset1 = [&]()
	{
		if(mina(id_n,0)) ++id;
	};
	FOR(i,0,R)
	{
		FOR(j,0,C)
		{
			if(B[i][j] == '#') reset1();
			else id_h[i][j] = use1();
		}
		reset1();
	}
	FOR(j,0,C)
	{
		FOR(i,0,R)
		{
			if(B[i][j] == '#') reset1();
			else id_v[i][j] = use1();
		}
		reset1();
	}
	FOR(j,0,R+C-1)
	{
		FOR(i,0,R) if(j-i >= 0 and j-i < C)
		{
			if(B[i][j-i] == '#') reset1();
			else id_s[i][j-i] = use1();
		}
		reset1();
	}
	FOR(j,-R+1,C)
	{
		FOR(i,0,R) if(j+i >= 0 and j+i < C)
		{
			if(B[i][j+i] == '#') reset1();
			else id_b[i][j+i] = use1();
		}
		reset1();
	}
	const int N {id};

	int jr {0};
	int jc {0};
	FOR(i,0,R) FOR(j,0,C) if(B[i][j] == 'J')
	{
		jr = i;
		jc = j;
		goto out1;
	}
out1:
	auto add_edge = [&](int a, int b)
	{
		E[a].PB(b);
		E[b].PB(a);
	};
	FOR(i,0,R) FOR(j,0,C) if(B[i][j] != '#')
	{
		add_edge(id_h[i][j], id_v[i][j]);
		add_edge(id_s[i][j], id_b[i][j]);
	}

	fill(dist, dist + N, inf);
	queue<int> Q;
	auto f = [&](int u, int d)
	{
		if(mina(dist[u], d)) Q.push(u);
	};
	f(id_h[jr][jc], 0);
	f(id_v[jr][jc], 0);
	f(id_s[jr][jc], 0);
	f(id_b[jr][jc], 0);
	while(!Q.empty())
	{
		int u {Q.front()};
		Q.pop();
		int d1 {dist[u] + 1};
		for(int v: E[u]) f(v, d1);
	}

	REP(K)
	{
		cint2(r,c);
		--r; --c;
		int res {
			min(
				min(dist[id_h[r][c]], dist[id_v[r][c]]),
				min(dist[id_s[r][c]], dist[id_b[r][c]]))
		};
		if(res == inf) res = -1;
		cout << res << nl;
	}

	return 0;
}