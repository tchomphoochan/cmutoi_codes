// 130 - Mahou Shoujo
// Solution by AquaBlitz11

#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const int N = 1e5+10;
const ll INF = 1e18;

vector<ll> solve(int n, int k, const vector<ll> &A)
{
	vector<ll> dp(n+1), C(n+1);
	deque<int> ix;
	auto cmp = [&] (int a, int b) {
		ll v = dp[a-1]+C[a] - (dp[b-1]+C[b]);
		if (v != 0) return v < 0;
		return a < b;
	};
	set<int, decltype(cmp)> s(cmp);
	for (int i = 1; i <= n; ++i) {
		if (!ix.empty() && ix.back() == i-k) {
			int p = ix.back();
			s.erase(p);
			ix.pop_back();
			if (ix.empty() || p+1 != ix.back()) {
				C[p+1] = C[p];
				ix.push_back(p+1);
				s.insert(p+1);
			}
		}
		C[i] = A[i];
		int lix = i;
		while (!ix.empty() && C[ix.front()] <= C[i]) {
			lix = ix.front();
			s.erase(lix);
			ix.pop_front();
		}
		ix.push_front(lix);
		C[lix] = A[i];
		s.insert(lix);
		dp[i] = dp[(*s.begin())-1] + C[*s.begin()];
	}
	return dp;
}

int main()
{
	int n, k;
	scanf("%d%d", &n, &k);
	vector<ll> A(n+1);
	for (int i = 1; i <= n; ++i)
		scanf("%lld", &A[i]);
	vector<ll> ans = solve(n, k, A);
	printf("%lld\n", ans[n]);

	return 0;
}