// 88 - Light Saber
// Solution by noneTP

#include <cstdio>

int ans[105];

int main(){
	int n, a, b;
	scanf("%d%d%d", &n, &a, &b);

	if(a > n || b > n){
		printf("IMPOSSIBLE\n");
		return 0;
	}
	else if(a == 1){
		if(b == n) for(int i=n;i>=1;i--) printf("%d ", i);
		else printf("IMPOSSIBLE\n");
		return 0;
	}
	else if(b == 1){
		if(a == n) for(int i=1;i<=n;i++) printf("%d ", i);
		else printf("IMPOSSIBLE\n");
		return 0;
	}
	
	int j = 1, cnt = 0;
	for(int i=n-a+1;i<=n;i++) ans[j++] = i;

	int lst = n-a;
	int beg = 1;

	int leg = 0;
	
	while(beg <= lst){
		int lim = beg+b-2 > lst? lst:beg+b-2;
		if(beg == 1) leg = lim-beg+2;
		for(int i=lim;i>=beg;i--) ans[j++] = i;
		beg = beg+b-1;
		cnt++;
	}

	if(cnt > a || leg != b){
		printf("IMPOSSIBLE\n");
		return 0;
	}

	for(int i=1;i<=n;i++) printf("%d ", ans[i]);
}