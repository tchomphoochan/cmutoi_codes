// 136 - New Year Party
// Solution by AquaBlitz11

#include <algorithm>
#include <cassert>
#include <iostream>

using namespace std;
const int N = 410;
const int N_LIMIT = 400;
int color[N];
bool knapsack[N];
bool newknapsack[N];
bool flag;
bool adj[N][N];
int n, m;

// nCr for test case validation checking
inline int nC2(int n) { return n * (n + 1) / 2; }

// find the component, raise flag if it's not bipartite
pair<int, int> dfs(int u, int clr = 0);

int main(void)
{
	cin.sync_with_stdio(false);

	// read num of test cases
	int num_test;
	cin >> num_test;
	while (num_test--)
	{
		// read num of nodes and num of edges
		cin >> n >> m;
		assert(1 <= n and n <= N_LIMIT);
		assert(0 <= m and m <= nC2(n));

		// reset adj, color, knapsack and flag
		for_each(adj + 1, adj + n + 1, [](bool *arr) {
			fill(arr + 1, arr + n + 1, false);
		});
		fill(color + 1, color + n + 1, -1);
		fill(knapsack, knapsack + n + 1, false);
		flag = false;

		// read graph
		for (int i = 0; i < m; ++i)
		{
			int u, v;
			cin >> u >> v;
			assert(1 <= u and u <= n);
			assert(1 <= v and v <= n);
			adj[u][v] = adj[v][u] = true;
		}

		// compute complement graph
		for (int u = 1; u <= n; ++u)
		{
			for (int v = 1; v <= n; ++v)
			{
				if (u != v)
				{
					adj[u][v] = not adj[u][v];
				}
			}
		}

		// compute each component separately
		knapsack[0] = true;
		for (int u = 1; u <= n; ++u)
		{
			if (color[u] == -1)
			{
				fill(newknapsack, newknapsack + n + 1, false);
				// new componet found
				pair<int, int> res = dfs(u);
				int sz1 = res.first;
				int sz2 = res.second;
				// update knapsack with sz1
				for (int i = n - sz1; i >= 0; --i)
				{
					if (knapsack[i])
					{
						newknapsack[i + sz1] = true;
					}
				}
				// update knapsack with sz2
				for (int i = n - sz2; i >= 0; --i)
				{
					if (knapsack[i])
					{
						newknapsack[i + sz2] = true;
					}
				}
				copy(newknapsack, newknapsack + n + 1, knapsack);
			}
		}

		if (flag)
		{ // flag is raised
			cout << -1 << endl;
		}
		else
		{
			// find the best configuration
			int ans = n;
			for (int sz = 0; sz <= n; ++sz)
			{
				if (knapsack[sz])
				{
					ans = min(ans, abs((sz) - (n - sz)));
				}
			}

			// report the answer
			cout << ans << endl;
		}
	}

	return 0;
}

pair<int, int> dfs(int u, int clr)
{
	if (color[u] != -1)
	{
		// if the node is visited
		if (color[u] != clr)
		{
			// raise flag when the color is incorrect
			flag = true;
		}
		return {0, 0};
	}

	// set color
	color[u] = clr;

	// continue searching
	pair<int, int> ans = {clr == 0, clr == 1};
	for (int v = 1; v <= n; ++v)
	{
		if (adj[u][v])
		{
			pair<int, int> result = dfs(v, not clr);
			ans = {ans.first + result.first, ans.second + result.second};
		}
	}

	return ans;
}