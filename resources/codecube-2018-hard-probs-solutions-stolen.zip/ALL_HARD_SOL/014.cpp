// 14 - Lazy Engineer
// Solution by zoomswk

#include <stdio.h>
#include <queue>
using namespace std;

vector< pair< int, pair<int, int> > > edge[1005]; // { no., {u, v} }
priority_queue< pair<int, pair<int, int> > > q; // { w, {loc, type} }
int visited[1005][2];
int total[1005][2];
int req[1005][2];

int max(int a, int b) { if(a>b) return a; return b; }

int main(){
	int n, m, u, v, w, type;
	int x, d, to;
	scanf("%d%d", &n, &m);
	for(int i=1; i<=m; i++){
		scanf("%d%d%d", &u, &v, &w);
		edge[u].push_back({i,{w,v}});
		edge[v].push_back({i,{w,u}});
	}
	q.push({0,{1, 1}});
	while(!q.empty()){
		d = -q.top().first;
		x = q.top().second.first;
		type = q.top().second.second;
		q.pop();
		if(visited[x][type]) continue;
		for(int i=0; i<edge[x].size(); i++){
			to = edge[x][i].second.second;
			if(visited[to][!type]) continue;
			if(d + edge[x][i].second.first == total[to][!type]){
				req[to][!type] = -max(-max(edge[x][i].first, req[x][type]), -req[to][!type]);
			}
			if(d + edge[x][i].second.first >= total[to][!type] && total[to][!type] > 0) continue;
			total[to][!type] = d + edge[x][i].second.first;
			req[to][!type] = max(edge[x][i].first, req[x][type]);
			q.push({-total[to][!type],{to,!type}});
		}
		visited[x][type] = 1;
	}
	printf("%d %d", req[n][0], total[n][0]);
}