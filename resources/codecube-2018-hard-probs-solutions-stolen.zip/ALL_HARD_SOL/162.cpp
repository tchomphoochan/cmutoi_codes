// 162 - Simple Graph
// Solution by AquaBlitz11

#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const int N = 100010;
ll deg[N], qs[N];

int main()
{
	int t;
	scanf("%d", &t);
	while (t--) {

		int n;
		scanf("%d", &n);
		for (int i = 1; i <= n; ++i)
			scanf("%lld", &deg[i]);
		sort(deg+1, deg+n+1, greater<ll>());

		qs[n+1] = 0;
		for (int i = n; i >= 1; --i)
			qs[i] = qs[i+1] + deg[i];
		
		bool fail = qs[1] % 2 != 0;

		ll s = 0;
		for (int k = 1; k <= n && !fail; ++k) {

			s += deg[k];
			ll v1 = (ll)k*(k-1);

			ll low = lower_bound(deg+k+1, deg+n+1, k, greater<ll>()) - deg;
			ll v2 = k*(low-k-1) + qs[low];
			
			/*ll v2 = 0;
			for (int i = k+1; i <= n; ++i)
				v2 += min(deg[i], (ll)k);*/

			if (s > v1+v2)
				fail = true;

		}

		if (!fail)
			printf("Yes\n");
		else
			printf("No\n");
	}
}