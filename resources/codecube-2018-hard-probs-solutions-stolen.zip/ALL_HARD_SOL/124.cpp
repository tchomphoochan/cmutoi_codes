// 124 - COI Cube Balloon
// Solution by zawini54

#include <bits/stdc++.h>
using namespace std;
const int MAXN = (1e5)+1, MAXM = (1e6)+1;

int n, m, par[MAXN], sub[MAXN];
set<pair<int, pair<int,int> > > q;
int main() {
	scanf("%d%d",&n,&m);
	for(int i = 1; i <= n; i++) {
		scanf("%d", sub+i);
		par[i] = i;
	}
	for(int i = 1; i <= m; i++) {
		int inst, a, b, t, add;
		scanf("%d",&inst);
		while(!q.empty() && q.begin()->first == i) {
			auto p = q.begin()->second;
			int x = p.first;
			while(par[x] != x) x = par[x];
			sub[x] += p.second;
			q.erase(q.begin());
		}
		if(inst == 1) {
			scanf("%d",&a);
			for(int x = a; x != par[x]; x = par[x]) sub[par[x]] -= sub[a];
			par[a] = a;
		} else if(inst == 2) {
			scanf("%d%d%d%d",&a,&b,&t,&add);
			bool found = false;
			int root = b;
			for(int x = b; x != par[x]; x = par[x]) root = par[x];
			if(a == root) continue;
			for(int x = a; x != par[x]; x = par[x]) sub[par[x]] -= sub[a];
			par[a] = root;
			for(int x = a; x != par[x]; x = par[x]) sub[par[x]] += sub[a];
			q.emplace(t, make_pair(a, add));
		} else {
			scanf("%d",&a);
			int x = a;
			while(par[x] != x) x = par[x];
			printf("%d\n", sub[x]);
		}
	}
}