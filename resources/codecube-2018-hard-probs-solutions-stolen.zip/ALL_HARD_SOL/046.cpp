// 46 - Tons of Pirates
// Solution by kimmypracha

#include<bits/stdc++.h>
using namespace std;
typedef struct KK
{
	int t,s,e;
};
vector<int> P;
int FW[200005]={};
void update(int pos,int val)
{
	while(pos<P.size())
	{
		FW[pos]+=val;
		pos+=pos&(-pos);
	}
}
int query(int pos)
{
	int sum=0;
	while(pos>0)
	{
		sum+=FW[pos];
		pos-=pos&(-pos);
	}
	return sum;
}
int main()
{
   int kon,order;
   vector<KK> O;
   scanf("%d%d",&kon,&order);
   int a,b,c;
   P.push_back(0);
   for(int i=0;i<order;i++)
   {
	   scanf("%d",&a);
	   if(a)
	   {
		   scanf("%d%d",&b,&c);
			P.push_back(b);
			P.push_back(c);
	   }
	   else{
		   scanf("%d",&b);
		   P.push_back(b);
	   }
		O.push_back({a,b,c});
   }
   sort(P.begin(),P.end());
   auto it = unique(P.begin() , P.end());
   P.resize(distance(P.begin() , it));
   for(int i=0;i<O.size();i++)
   {
	   if(O[i].t)
	   {
		   int S=(lower_bound(P.begin(),P.end(),O[i].s)-P.begin());
		   int E=(lower_bound(P.begin(),P.end(),O[i].e)-P.begin());
		   update(S,1);
		   update(E+1,-1);
	   }
	   else
		{
			int k=(lower_bound(P.begin(),P.end(),O[i].s)-P.begin());
			int x=query(k);
			if(x%6==0)
				printf("sleep\n");
			else if(x%6==1||x%6==3||x%6==5)
				printf("eat\n");
			else
				printf("work\n");
		}
   }
}