// 101 - Activity Selection
// Solution by zoomswk

#include <stdio.h>
#include <algorithm>
using namespace std;

int A[200005], B[200005];
pair<pair<int, int>, int> p[200005];
int taken[200005];

int main(){
	int N;
	scanf("%d", &N);
	long long sumA=0, sumB=0;
	for(int i=1; i<=2*N-1; i++){
		scanf("%d%d", &A[i], &B[i]);
		sumA += A[i], sumB += B[i];
		p[i].first.first = A[i], p[i].first.second = B[i], p[i].second = i;
	}
	sort(p+1, p+2*N);
	sumA = (sumA+1)/2;
	sumB = (sumB+1)/2;
	int cnt=0;
	for(int i=2*N-1; i>=0 && sumA > 0 && cnt <= N/2; i--){
		sumA -= p[i].first.first, sumB -= p[i].first.second;
		cnt++;
		taken[p[i].second] = 1;
	}
	for(int i=1; i<=2*N-1; i++) swap(p[i].first.first, p[i].first.second);
	sort(p+1, p+2*N);
	for(int i=2*N-1; i>=0 && sumB > 0; i--){
		if(taken[p[i].second]) continue;
		sumA -= p[i].first.second, sumB -= p[i].first.first;
		cnt++;
		taken[p[i].second] = 1;
	}
	for(int i=1; cnt < N; i++) if(!taken[i]) taken[i] = 1, cnt++;
	for(int i=1; i<=2*N-1; i++) if(taken[i]) printf("%d ", i);
	return 0;
}