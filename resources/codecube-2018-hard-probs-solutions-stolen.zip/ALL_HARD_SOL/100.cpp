// 100 - Love Letter
// Solution by Chimeng

#include <stdio.h>

typedef long long ll;

const int N = 100005;

ll qs[N][10];
/**	  ^
		 |
meaning each index
L	= 0
O	= 1
LO   = 2
V	= 3
OV   = 4
LOV  = 5
E	= 6
VE   = 7
OVE  = 8
LOVE = 9
*/
char str[N];

int main(){
	int n, Q;
	scanf("%d %s %d", &n, str+1, &Q);

	// make quick sum of 'love' subsequence
	for (int i = 1; i <= n; ++i) {
		for (int j = 0; j < 10; ++j)
			qs[i][j] = qs[i-1][j];

		if (str[i] == 'L') {
			qs[i][0] = qs[i-1][0]+1;
		}else if (str[i] == 'O') {
			qs[i][1] = qs[i-1][1]+1;
			qs[i][2] = qs[i-1][2]+qs[i-1][0];
		}else if (str[i] == 'V') {
			qs[i][3] = qs[i-1][3]+1;
			qs[i][4] = qs[i-1][4]+qs[i-1][1];
			qs[i][5] = qs[i-1][5]+qs[i-1][2];
		}else { // case 'E'
			qs[i][6] = qs[i-1][6]+1;
			qs[i][7] = qs[i-1][7]+qs[i-1][3];
			qs[i][8] = qs[i-1][8]+qs[i-1][4];
			qs[i][9] = qs[i-1][9]+qs[i-1][5];
		}
	}

	while (Q--) {
		int l, r;
		scanf("%d%d", &l, &r);
		ll cnt_E   = qs[r][6]-qs[l-1][6];
		ll cnt_VE  = qs[r][7]-qs[l-1][7]-qs[l-1][3]*cnt_E;
		ll cnt_OVE = qs[r][8]-qs[l-1][8]-qs[l-1][4]*cnt_E-qs[l-1][1]*cnt_VE;
		ll cntLOVE = qs[r][9]-qs[l-1][9]-qs[l-1][5]*cnt_E-qs[l-1][2]*cnt_VE-qs[l-1][0]*cnt_OVE;
		printf("%lld\n", cntLOVE);
	}
	return 0;
}