// 25 - A-Point
// Solution by AquaBlitz11

#include <bits/stdc++.h>
using namespace std;

using ll = long long;

const int N = 610;

int arr[N], qs[N];
ll dp[N][N];

int main()
{
	int n;
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i) {
		scanf("%d", &arr[i]);
		qs[i] = qs[i-1]+arr[i];
	}
	for (int s = 2; s <= n; ++s) {
		for (int i = 1; i <= n-s+1; ++i) {
			int j = i+s-1;
			for (int k = i; k < j; ++k) {
				int a = qs[k]-qs[i-1];
				int b = qs[j]-qs[k];
				if (a > b)
					swap(a, b);
				dp[i][j] = max(dp[i][j], dp[i][k]+dp[k+1][j]+(2*a+b));
			}
		}
	}
	printf("%lld\n", dp[1][n]);

	return 0;
}