// 155 - Joddad Valley
// Solution by kimmypracha

#include <bits/stdc++.h>
#define eb emplace
 using namespace std;
   const int lim = 220;
   const double eps = 1e-6;
   typedef struct node{
		double wei , vel;
		int pos;
		node(double a , double b , int c) : wei(a) , vel(b) , pos(c) {};
		bool operator < (const node &x )const {
			if(fabs(wei - x.wei) <= eps) return vel < x.vel;
			return wei > x.wei;
		}
   };
	 int n , m ,q;
   double G[lim][lim];
   double dp[lim];
	double dijkstra(int s , int t , double v , double c){
		  priority_queue<node> pq;
		  pq.eb(0,v , s);
		  fill(dp , dp + lim , -1);
		  dp[s] = 0;
		  while(not pq.empty()){
			  int now = pq.top().pos;
			  double wei = pq.top().wei;
			  double vel = pq.top().vel;
			  //printf("%d : %f %f\n",now , wei , vel);
			  pq.pop();
			  if(vel <= eps)continue;
			  for(int i = 1 ; i <=n ; ++i){
					if(G[now][i] >= 0 and (dp[i] > dp[now] + G[now][i]/vel or dp[i] < 0)){
						  dp[i] = dp[now] + G[now][i]/vel;
						  pq.eb(dp[i] , vel - G[now][i]*c  , i);
					}
			  }
		  }
		  return dp[t];
	}
   int main(){

		scanf("%d%d%d",&n,&m,&q);
		for(int i =1 ; i  <= n ;++i){
		  for(int j = 1 ; j <= n; ++j){
				G[i][j] = G[j][i] = -1;
		  }
		}
		for(int i =0  ; i < m ; ++i){
			int a  ,b;
			double w;
			scanf("%d%d%lf",&a,&b,&w);
			if(G[a][b] < 0) G[a][b] = G[b][a] = w;
			G[a][b] = G[b][a] = min(G[a][b] , w);
		}
		while(q--){
			string op;
			cin >> op;
			if(op[0] == 't'){
				int s , t ;
				double v , c;
				scanf("%d%d%lf%lf",&s,&t,&v,&c);
				double ans = dijkstra(s,t,v,c);
				if(ans < 0){
				  printf("IMPOSSIBLE\n");
				}else{
				  printf("%.6lf\n",ans);
				}
			}else if(op[0] == 'a'){
				int a , k;
				scanf("%d%d",&a,&k);
				for(int i =0 ; i < k ; ++i){
					  int b;
					  double w;
					  scanf("%d%lf",&b,&w);
					  if(G[a][b] < 0 )G[a][b] = G[b][a] = w;
					  else G[a][b] = G[b][a] = min(G[a][b] , w);
				}
			}else{
				int a;
				scanf("%d",&a);
				for(int i = 1  ; i <= n ; ++i){
					G[i][a] = G[a][i] = -1;
				}
			}
		}
   }