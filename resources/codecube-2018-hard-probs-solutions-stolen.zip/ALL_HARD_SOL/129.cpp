// 129 - A Kid and Dominoes
// Solution by spnautilus

// spnauT
//
#include <bits/stdc++.h>
using namespace std;
#define FOR(i,a,b) for(int _b=(b),i=(a);i<_b;++i)
#define ROF(i,b,a) for(int _a=(a),i=(b);i>_a;--i)
#define REP(n) for(int _n=(n);_n--;)
#define _1 first
#define _2 second
#define PB(x) push_back(x)
#define SZ(x) int((x).size())
#define ALL(x) (x).begin(),(x).end()
#define MSET(m,v) memset(m,v,sizeof(m))
#define MAX_PQ(T) priority_queue<T>
#define MIN_PQ(T) priority_queue<T,vector<T>,greater<T>>
#define IO(){ios_base::sync_with_stdio(0);cin.tie(0);}
#define nl '\n'
#define cint1(a) int a;cin>>a
#define cint2(a,b) int a,b;cin>>a>>b
#define cint3(a,b,c) int a,b,c;cin>>a>>b>>c
typedef long long LL;typedef pair<int,int> PII;
typedef vector<int>VI;typedef vector<LL>VL;typedef vector<PII>VP;
template<class A,class B>inline bool mina(A &x,const B &y){return(y<x)?(x=y,1):0;}
template<class A,class B>inline bool maxa(A &x,const B &y){return(x<y)?(x=y,1):0;}

#define MAXN (100004)

int A[MAXN];
int P[MAXN];
int L[MAXN];
int R[MAXN];

int main()
{
	IO();
	cint1(N);
	FOR(i,1,N+1)
	{
		cint1(a);
		A[i] = a;
		P[a] = i;
	}

	int sol = min(N,2);

	if(N >= 3)
	{
		auto f = [&]()
		{
			FOR(i,1,N-1)
			{
				if(A[i] < A[i+1] && A[i+1] < A[i+2]) return 1;
				FOR(j,0,3) FOR(k,j+1,3)
				{
					swap(A[i+j],A[i+k]);
					int res = 0;
					if(A[i] < A[i+1] && A[i+1] < A[i+2]) res = 1;
					swap(A[i+j],A[i+k]);
					if(res) return 1;
				}
			}
			return 0;
		};
		if(f()) sol = 3;

		L[1] = 1;
		int a = 1;
		FOR(i,2,N+1)
		{
			if(A[i-1] > A[i]) a = 0;
			L[i] = ++a;
		}
		a = 1;
		R[N] = 1;
		ROF(i,N-1,0)
		{
			if(A[i] > A[i+1]) a = 0;
			R[i] = ++a;
		}

		FOR(i,1,N+1) maxa(sol, L[i]);

//		FOR(i,1,N+1) printf("%d : %d %d %d\n", i, A[i], L[i], R[i]);

		FOR(i,1,N)
		{
			if(A[i] > A[i+1])
			{
				int l = (i == 1 || A[i+1] < A[i-1]) ? 0 : L[i-1];
				int r = (i == N-1 || A[i] > A[i+2]) ? 0 : R[i+2];
				maxa(sol, l+r+2);
			}
			else
			{
				int l = (i == 1 || A[i+1] < A[i-1]) ? 0 : L[i-1];
				int r = (i == N-1 || A[i] > A[i+2]) ? 0 : R[i+2];
				maxa(sol, l+1);
				maxa(sol, r+1);
			}
		}

		FOR(i,2,N+1) if(A[i] > 1) maxa(sol, R[i]+1);
		FOR(i,1,N) if(A[i] < N) maxa(sol, L[i]+1);

		FOR(i,2,N) if(A[i-1]+2 <= A[i+1]) maxa(sol, L[i-1] + 1 + R[i+1]);

		FOR(i,2,N) if(L[i] == 1 && i+R[i] != N+1)
		{
			int a = i-1;
			int b = i+R[i];
			int l,r;

			swap(A[a],A[b]);
			if(A[a] < A[a+1])
			{
				if(a > 1 && A[a-1] < A[a]) l = 1 + L[a-1];
				else l = 1;
			}
			else l = 0;
			if(A[b-1] < A[b])
			{
				if(b < N && A[b] < A[b+1]) r = 1 + R[b+1];
				else r = 1;
			}
			else r = 0;
			swap(A[a],A[b]);

			maxa(sol, R[i]+l+r);
		}
	}
	cout << sol << nl;

	return 0;
}