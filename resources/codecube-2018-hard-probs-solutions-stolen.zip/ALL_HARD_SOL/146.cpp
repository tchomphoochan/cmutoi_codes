// 146 - E - Stop The Conflict (Large)

#include<cstdio>
#include<algorithm>
#include<vector>

using namespace std;

pair<int, int> P[201];
vector< pair<int, int> > ans;

int parent[201];
int child[201];

int main(){
	int n, m, k;
	scanf("%d%d%d", &n, &m, &k);

	int tmp1 = 0;
	int tmp2 = 0;

	for(int i=0;i<m;i++){
		int a, b, c, d;
		scanf("%d%d%d%d", &a, &b, &c, &d);
		P[a].first += c+d;
		P[b].first += c+d;
		P[a].second = a;
		P[b].second = b;

		tmp1 += c;
		tmp2 += d;
	}
	if(tmp1 - tmp2 != 0){
		printf("-1\n");
		return 0;
	}
	sort(P+1, P+n+1);

	for(int i=1;i<=n;i++){
		parent[i] = i;
		child[i] = i;
	}

	// find parent&child
	for(int i=n-1;i>=1;i--){
		if(P[i].first == P[i+1].first){
			parent[i] = parent[i+1];
			child[parent[i]] = i;
		}
	}

	int b = n;
	int num = 0;
	int sum = 0;

	while(b){
		num = b-child[b]+1;
		if(num%2 == 1){
			if(sum != 0){
				ans.push_back(make_pair(sum - P[child[b]].first, P[child[b]].second));
				sum = 0;
			}
			else sum = P[b].first;
		}
		b = child[b]-1;
	}

	if(sum != 0 || ans.size() == 0){
		if(ans.size() == 0) printf("0\n");
		else printf("-1\n");
	}
	else{
		printf("%lu\n", ans.size());
		for(int i=0;i<ans.size();i++){
			printf("%d %d %lf\n", ans[i].second, ans[i].second, (double)ans[i].first/4);
		}
	}
}