// 37 - Sabuza
// Solution by win11905

#include <bits/stdc++.h>
#define long long long
#define P pair<int, int>
#define x first
#define y second
#define input() (*istream_iterator<int>(cin))
#define all(x) (x).begin(), (x).end()
#define mem(x) memset(x, 0, sizeof x)
#ifndef INPUT
#define dbg(x) cout << "debug : " << x << endl
#define dbg2(x, y) cout << "debug : " << x << " " << y << endl
#else
#define dbg(x)
#define dbg2(x, y)
#endif
using namespace std;


void red() {
	freopen("r", "r", stdin);
}

const int MAXN = 5e4+5;

long dp[MAXN], inf = 1e18;

vector<pair<int, long> > S; // m , c;

bool cut(pair<int, long> now) {
	int d1 = S.size() - 2, d2 = S.size() - 1;
	double x = (double)(S[d1].x-now.x)/(now.y-S[d1].y);
	double y = (double)(S[d2].x-now.x)/(now.y-S[d2].y);
	if(x < y) return true;
	return false;
}

int f(int x, int y) {
	if(x == 0) return true;
	long x1 = (long)S[x-1].x*y + S[x-1].y;
	long x2 = (long)S[x].x*y + S[x].y;
	return x1 > x2; 
}

int main() {
	int T = input();
	vector<P> V;
	while(T--) {
		int a = input(), b = input(), c = input();
		V.emplace_back(a*b, c);
	}
	sort(all(V), greater<P>());
	vector<P> ret;
	int mx = 0, n = 0;
	ret.emplace_back(0, 0);
	for(auto x : V) {
		if(x.y > mx) {
			mx = x.y;
			ret.emplace_back(x);
			//cout << x.x << " : " << x.y << endl;
			n++;
		} //else cout << "delete " << x.x << " : " << x.y << endl;
	}
	fill(dp+1, dp+MAXN, inf);
	// for(int i = 1; i <= n; ++i) {
	// 	for(int j = 1; j <= i; ++j) {
	// 		dp[i] = min(dp[i], dp[j-1] + (long)ret[j].x*ret[i].y);
	// 	}
	// }
	for(int i = 1; i <= n; ++i) {
		while(S.size() >= 2 && cut(make_pair(ret[i].x, dp[i-1]))) S.pop_back();
		S.emplace_back(ret[i].x, dp[i-1]);

		int L = 0, R = S.size()-1;
		while(L < R) {
			int mid = (L+R+1)/2;
			// if P(S[i-1]) > P(S[i])
			if(f(mid, ret[i].y)) L = mid;
			else R = mid-1;
		}
		dp[i] = (long)S[L].x*ret[i].y + S[L].y;
	}
	cout << dp[n];
}