// 53 - คู่หูเกมเมอร์ (Duo of Gamer)
// Solution by kimmypracha

#include <bits/stdc++.h>

 using namespace std;
   typedef struct{
	   int a,b,c,v;
   }QE;
 int DP[61][101][101]={};
 queue<QE> q;
  int main(){
	QE C;
   int Q,N,A,B,K,X,Y,V,Ans = 0,L,i,j,k,l;
   scanf("%d",&Q);
   ++Q;
   while(--Q){
		Ans = 0;
		q = queue<QE>();
	scanf("%d%d%d%d",&N,&A,&B,&K);
	for(i=0;i<N;++i){
		scanf("%d%d%d",&X,&Y,&V);
		if(i){
			for(j=1;j<=A;++j){
				for(k=1;k<=B;++k){
						if(j<=X&&k<=Y)continue;
					for(l=0;l<=60;++l){
						if(DP[l][j][k]){
							if(j>X&&l>=0&&DP[l][j][k]+V >DP[l-1][j-X][k])q.push({j-X,k,l-1,DP[l][j][k]+V});
							if(k>Y&&l<60&&DP[l][j][k]+V > DP[l+1][j][k-Y])q.push({j,k-Y,l+1,DP[l][j][k]+V});
						}
					}
				}
			}
		  }
			while(!q.empty()){
				C = q.front();
				q.pop();
				DP[C.c][C.a][C.b] = max(DP[C.c][C.a][C.b],C.v);
				if(abs(C.c-30)<=K)
				Ans = max(Ans,DP[C.c][C.a][C.b]);
			}
			if(A-X>0){
				DP[29][A-X][B] = max(DP[29][A-X][B],V);
				Ans = max(Ans,DP[29][A-X][B]);
			}
			if(B-Y>0){
				DP[31][A][B-Y] = max(DP[31][A][B-Y],V);
				Ans = max(Ans,DP[31][A][B-Y]);
			}
		}
	printf("%d\n",(!K)? 0 : Ans);
	for(i=1;i<=A;++i){
		for(j=1;j<=B;++j){
			for(k=0;k<=60;++k){
				DP[k][i][j] = 0;
			}
		}
	}
   }
  }