// 135 - Chirstmas Tree
// Solution by krist7599555

#include <bits/stdc++.h>
#include <iostream>
#include <cstring>
#define input() (*std::istream_iterator<int>(cin))
#define rep(i,k,n) for(int i=(k);i!=int(n);++i)
#define loop(i,n) for(int i = n; i--;)
#define all(x) (x).begin(),(x).end()
#define sz(x) int((x).size())
#define fi first
#define se second
using namespace std;
typedef std::vector<int> Vec;

const int mxn = 1e5 + 10;
int n;
Vec edge[mxn];

void ans(Vec v = Vec()){
	if (v.empty())  puts("IMPOSSIBLE");
	for (int i : v) printf("%d ", i);
	std::exit(0);
}

Vec path (int u){
	if (u == 1) return Vec(1, 1);
	for (int v : edge[u]){
		if (v < u){
			Vec res = path(v);
			if (not res.empty()){
				res.push_back(u);
				return res;
	}}}
	return Vec();
}

bool is_in_bound (int u, int p, int l, int r){ // (exclude, exclude)
	std::queue<std::tuple<int,int,int,int>> que;
	que.emplace(u, p, l, r);
	while (not que.empty()){
		tie(u, p, l, r) = que.front();
		if (u <= l or r <= u) return false;
		for (int v : edge[u]){
			if (v != p){
				if (v < u) que.emplace(v, u, l, u);
				if (u < v) que.emplace(v, u, u, r);
		}}
		que.pop();
	}
	return true;
}
/*
6
1 2
2 4
4 5
5 3
4 6
*/

int main(){
	cin.sync_with_stdio(0);
	cin >> n;
	loop(_,n-1){
		int u = input();
		int v = input();
		assert (1 <= u and u <= n
			and 1 <= v and v <= n);
		edge[u].emplace_back(v);
		edge[v].emplace_back(u);
	}
	if (sz(edge[1]) > 2 or 
		sz(edge[n]) > 2 or 
		std::any_of(edge, edge+mxn,[](const Vec& v){ return sz(v) > 3; })) 
			::ans();
	const Vec pat = path(n);
	assert (std::is_sorted(all(pat)));
	
	if (pat.empty()) ::ans();
	int pl = 0, pr = sz(pat);

	rep(i,0,sz(pat)){
		int u = pat[i];
		int l = i != 0		 ? pat[i-1] : 0;
		int r = i != sz(pat)-1 ? pat[i+1] : mxn;
		for (int v : edge[u]){
			if (v != l and v != r){
				if (v < u){
					if (is_in_bound(v, u, l, u)) pr = std::min(pr, i);
					else ::ans();	
				}
				if (u < v){
					if (is_in_bound(v, u, u, r)) pl = std::max(pl, i+1);
					else ::ans();
				}
		}}
	}
	::ans(pl <= pr ? Vec(pat.begin() + pl, pat.begin() + pr) : Vec());
}