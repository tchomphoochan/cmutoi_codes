// 118 - Lightning Game 2
// Solution by noneTP

#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
const int mod = 1e9 + 7; // popular mod

LL mid[35];
int dp[35][105];

int rec(LL m, int k, int d){
	if(m <= 0) return 1;
	if(m == 1) return 2;
	int idx = mid[d]-m;
	if(idx < 0) idx = -idx;
	if(dp[d][idx] != -1) return dp[d][idx];

	LL ans = 0, mid = m/2, le = mid, ri = m-mid, cl = le<k?le:k, cr = ri<k?ri:k;
	int res[cr+2], sum[cr+2];
	for(int i=0;i<=cr+1;i++){
		res[i] = rec(ri-i-1, k, d+1);
		if(i == 0) sum[i] = res[i];
		else sum[i] = (sum[i-1] + res[i])%mod;
	}
	int b = 0;
	if(ri > le) b++;
	for(int i=0;i<=cl;i++){
		int x = cr<k-i?cr:k-i;
		ans = (ans + (LL)res[i+b]*sum[x])%mod;
	}
	return dp[d][idx] = ans;
}

int main(){
	int t, k;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		LL n;
		scanf("%lld%d", &n, &k);
		printf("Case #%d: ", i);
		if(k > n) printf("%d\n", 0);
		else if(k == 0 || n == k) printf("%d\n", 1);
		else if(n == k-1) printf("%d\n", 2);
		else{
			LL m = n;
			for(int j=0;m;j++) mid[j] = m, m/=2;
			memset(dp, -1, sizeof(dp));
			int res1 = rec(n, k, 0);
			int res2 = 1;
			if(k > 1){
				memset(dp, -1, sizeof(dp));
				res2 = rec(n, k-1, 0);
			}
			printf("%d\n", (res1-res2+mod)%mod);
		}
	}
}