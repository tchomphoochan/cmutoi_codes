// 106 - Papercut
// Solution by krist7599555

#include <bits/stdc++.h>
using namespace std;

class PaperCut{
	
	private:
	
	static const int max_n = 1010;
	
	int unio[max_n];
	struct struc;
	
	vector<struc> var;
	map<int,vector<struc*>> tmp;
	
	
	struct struc{
		
		int x1,x2,y1,y2,parent;
		
		friend inline bool cross(struc& a, struc &b){
			
			if ((a.x1==a.x2) == (b.x1==b.x2)) return false;
			
			if(a.x1==a.x2)
					return 	a.y1 <= b.y1 && b.y2 <= a.y2 &&
							b.x1 <= a.x1 && a.x2 <= b.x2 ;
			
			else
					return  b.y1 <= a.y1 && a.y2 <= b.y2 &&
							a.x1 <= b.x1 && b.x2 <= a.x2 ;
		}
	};
	
	int fir(int now){
		return unio[now] == now ? now : fir(unio[now]);
	}
	
	
	public:
	
	static int trail;
	static int paperCount;
	
	
	PaperCut(){
		var.reserve(max_n);
		iota(unio,unio+max_n,0);
	}
	
	void add(int x1,int y1,int x2,int y2){
		
		struc now = {x1,x2,y1,y2,++trail};
		
		for (struc& old : var)
			if(cross(old,now))
				tmp[fir(old.parent)].emplace_back(&old);
		
		for (auto& it : tmp){
			paperCount += it.second.size()-1;
			for (struc* p : it.second){
				unio[fir(p->parent)] = trail;
			}
		}
		
		var.emplace_back(now);
		tmp.clear();
		
	}
	
};
int PaperCut::trail = 0;
int PaperCut::paperCount = 0;
PaperCut ppcut;

int main(){
	
	cin.sync_with_stdio(false);
	
	int R=2,C=2,l=0;
	cin >> R >> C >> l;
	ppcut.add(0,0,0,C);
	ppcut.add(R,0,R,C);
	ppcut.add(0,0,R,0);
	ppcut.add(0,C,R,C);
	
	while(l--){
		int x1,y1,x2,y2;
		cin >> x1 >> y1 >> x2 >> y2;
		if(x1>x2) swap(x1,x2);
		if(y1>y2) swap(y1,y2);
		ppcut.add(x1,y1,x2,y2);
		
	}
	
	cout << PaperCut::paperCount << endl;
	
	
	
}